<?php
// Check if the data is sent via POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the POST data and store it in a variable
    $postData = $_POST;
} else {
    // Handle the case where no data was sent
    echo "No data received.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Response</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your external styles.css -->
</head>
<body>
    <div class="response-container">
        <h2>Payment Response Details</h2>

        <!-- Table to display the POST data -->
        <table>
            <tr>
                <th>Parameter</th>
                <th>Value</th>
            </tr>
            <?php 
            // Loop through each item in the $postData array
            foreach ($postData as $key => $value) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($key) . "</td>"; // Parameter name
                echo "<td>" . htmlspecialchars($value) . "</td>"; // Parameter value
                echo "</tr>";
            }
            ?>
        </table>
        <!-- JSON format response -->
        <h3>JSON Response</h3>
        <pre><?php echo json_encode($postData, JSON_PRETTY_PRINT); ?></pre>
        
    </div>
</body>
</html>
