<?php
session_start();

// Load Config
$config = include('config.php');

// Read environment
$env = $_POST['environment'] ?? 'UAT';

// Load environment values
$merchantid   = $config[$env]['merchant_id'];
$aggregatorid = $config[$env]['aggregator_id'];
$secretKey    = $config[$env]['key'];
$refundUrl    = $config[$env]['api']['refund'];

// Read POST values
$transactiontype = "REFUND";
$transactionid   = $_POST['transactionid'] ?? '';
$originalid      = $_POST['originalid'] ?? '';
$amount          = number_format((float)($_POST['amount'] ?? 0), 2, '.', '');

// Prepare data for signature
$data = [
    'aggregatorID'   => $aggregatorid,
    'amount'         => $amount,
    'merchantId'     => $merchantid,
    'merchantTxnNo'  => $transactionid,
    'originalTxnNo'  => $originalid,
    'transactionType'=> $transactiontype
];

// Sort ascending by key
ksort($data);

// Build signature input
$dataToHash = implode("", $data);

// Generate secure hash
$secureHash = hash_hmac("sha256", $dataToHash, $secretKey);

// Create final request payload
$requestData = array_merge($data, ['secureHash' => $secureHash]);
$jsonPayload = json_encode($requestData);

// -------- CURL CALL --------
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $refundUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
curl_close($ch);

// -------- DISPLAY RESPONSE --------
echo "<h2>Refund API Response</h2>";
echo "<pre>";
echo "Request:\n";
print_r($requestData);

echo "\nResponse:\n";
print_r(json_decode($response, true));
echo "</pre>";
?>
