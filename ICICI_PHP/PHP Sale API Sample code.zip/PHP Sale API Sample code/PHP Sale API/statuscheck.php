<?php
$config = include('config.php');
date_default_timezone_set($config['timezone']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Check</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="form-container">

    <h2>Status Check</h2>

    <form id="paymentForm" action="submit_status.php" method="POST">

        <!-- Environment -->
        <label class="formtext">Environment</label>
        <select name="environment" id="envSelect"
            style="width:100%; padding:10px; margin:10px 0; border-radius:4px; border:1px solid #ddd;">
            <option value="UAT">UAT</option>
            <option value="LIVE">LIVE</option>
        </select>

        <!-- Merchant ID -->
        <label class="formtext">Merchant ID</label>
        <input type="text" id="merchantid" name="merchantid"
               value="<?php echo $config['UAT']['merchant_id']; ?>" readonly>

        <!-- Aggregator ID -->
        <label class="formtext">Aggregator ID</label>
        <input type="text" id="aggregatorid" name="aggregatorid"
               value="<?php echo $config['UAT']['aggregator_id']; ?>" readonly>

        <!-- Merchant Txn -->
        <label class="formtext">Merchant Txn No</label>
        <input type="text" id="transactionid" name="transactionid" required placeholder="Enter Merchant TxnNo">

        <!-- Original Txn -->
        <label class="formtext">Original Txn No</label>
        <input type="text" id="originalid" name="originalid" required placeholder="Enter Original TxnNo">

        <!-- TYPE = STATUS -->
        <input type="hidden" name="transactionype" value="STATUS">

        <div class="submit-container">
            <button type="submit" id="submitButton">
                <span id="submitText">Check Status</span>
                <div class="loader" id="loader"></div>
            </button>
        </div>

    </form>

</div>

<script>
    // PHP config passed to JS
    const config = <?php echo json_encode($config); ?>;

    const envSelect = document.getElementById('envSelect');
    const merchantInput = document.getElementById('merchantid');
    const aggregatorInput = document.getElementById('aggregatorid');

    // Auto update merchant + aggregator IDs
    envSelect.addEventListener('change', function () {
        const env = this.value;
        merchantInput.value = config[env]['merchant_id'];
        aggregatorInput.value = config[env]['aggregator_id'];
    });

    // Loader animation
    const paymentForm = document.getElementById('paymentForm');
    const loader = document.getElementById('loader');
    const submitButton = document.getElementById('submitButton');
    const submitText = document.getElementById('submitText');

    paymentForm.addEventListener('submit', () => {
        submitText.style.display = "none";
        loader.style.display = "block";
        submitButton.disabled = true;
    });
</script>

</body>
</html>
