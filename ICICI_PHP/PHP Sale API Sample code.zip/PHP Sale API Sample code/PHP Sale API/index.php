<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Gateway</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .button-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            text-align: center;
        }

        .nav-button {
            padding: 15px 30px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        .nav-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="button-container">
    <a href="initiatesale.php" class="nav-button">Payment Initiation</a>
    <a href="statuscheck.php" class="nav-button">Status Check</a>
    <a href="initiaterefund.php" class="nav-button">Refund Initiation</a>
</div>

</body>
</html>
