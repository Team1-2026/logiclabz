<?php

// ---- DEVICE / OS DETECTION ----
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

$isAndroid = stripos($userAgent, 'Android') !== false;
$isIOS     = stripos($userAgent, 'iPhone') !== false
         || stripos($userAgent, 'iPad') !== false
         || stripos($userAgent, 'iPod') !== false;

$deviceOS = 'OTHER';
if ($isAndroid) {
    $deviceOS = 'ANDROID';
} elseif ($isIOS) {
    $deviceOS = 'IOS';
}
// UAT Configuration - UPDATED MERCHANT ID
$secretKey  = "abc"; // UAT secret key
$apiUrl     = "https://qa.phicommerce.com/pg/api/generateQR";
$merchantId = "T_08883"; // Updated merchant ID

$upiQR         = ""; // Store UPI QR response
$error         = "";
$merchantRefNo = ""; // Initialize

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['amount'], $_POST['emailID'])
    && $_POST['amount'] !== ''
    && $_POST['emailID'] !== ''
) {
    // Sanitize inputs (basic)
    $amount  = trim($_POST['amount']);
    $emailID = trim($_POST['emailID']);

    // Generate unique merchant reference number
    $merchantRefNo = time() . rand(100, 999);

    // Step 1: Frontend inputs + fixed values
    $requestData = [
        "amount"        => $amount,
        "currency"      => "356",
        "emailID"       => $emailID,
        "merchantId"    => $merchantId,
        "merchantRefNo" => $merchantRefNo,
        "requestType"   => "UPIQR"
    ];

    // Step 2: Sort keys alphabetically and create plain hashtext
    ksort($requestData);
    $plainHashText = implode('', array_values($requestData));

    // Step 3: Generate secure hash
    $secureHash = hash_hmac('sha256', $plainHashText, $secretKey);

    // Step 4: Prepare form-urlencoded data
    $postData = http_build_query([
        'amount'        => $requestData['amount'],
        'currency'      => $requestData['currency'],
        'emailID'       => $requestData['emailID'],
        'merchantRefNo' => $requestData['merchantRefNo'],
        'requestType'   => $requestData['requestType'],
        'secureHash'    => $secureHash,
        'merchantId'    => $merchantId
    ]);

    // Step 5: Call API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    // curl_close() deprecated in PHP 8.5 – not needed anymore
    unset($ch);

    $responseData = json_decode($response, true);

    // Step 6: Capture UPI QR
    if ($httpCode == 200 && isset($responseData['respBody']['upiQR'])) {
        $upiQR = $responseData['respBody']['upiQR'];
    } else {
        $error = "API Error: " . ($responseData['respHeader']['desc'] ?? 'Unknown error');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Payment Form</title>
    <style>
        body { font-family: Arial; max-width: 500px; margin: 50px auto; padding: 20px; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 15px; font-size: 18px; background: #00C851; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #00a843; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <h2>Generate UPI QR Code</h2>

    <?php if ($upiQR): ?>
        <div class="success">
            <strong>Payment Link Generated!</strong><br>
            Merchant Ref: <?php echo htmlspecialchars($merchantRefNo); ?><br>
            <button onclick="window.open('<?php echo htmlspecialchars($upiQR); ?>', '_blank')" style="margin-top: 15px;">
                Pay Now ₹<?php echo htmlspecialchars($amount); ?>
            </button>
            <br><br>
            <strong>UPI Link:</strong><br>
            <a href="<?php echo htmlspecialchars($upiQR); ?>" target="_blank"><?php echo htmlspecialchars($upiQR); ?></a>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <div>
            <label><strong>Amount (₹)</strong></label><br>
            <input type="number" name="amount"
                   value="<?php echo isset($_POST['amount']) ? htmlspecialchars($_POST['amount']) : ''; ?>"
                   step="0.01" min="1" required>
        </div>

        <div>
            <label><strong>Email ID</strong></label><br>
            <input type="email" name="emailID"
                   value="<?php echo isset($_POST['emailID']) ? htmlspecialchars($_POST['emailID']) : ''; ?>"
                   required>
        </div>

        <button type="submit">Generate & Pay Now</button>
    </form>
</body>
</html>
