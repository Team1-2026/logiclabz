<?php
session_start();

// Load configuration
$config = include('config.php');
// Environment selected by user (UAT or LIVE)
$env = $_POST['environment'] ?? 'uat';

// Validate environment
if (!isset($config[$env])) {
    die("Invalid environment selected.");
}
$merchantid   = $config[$env]['merchant_id'];
$aggregatorid = $config[$env]['aggregator_id'];
$secretKey    = $config[$env]['key'];
$apiEndpoint  = $config[$env]['api']['initiate_sale'];
$returnurl    = $config[$env]['return_url'];
date_default_timezone_set($config['timezone'] ?? 'Asia/Kolkata');

// Collect POST data
$name            = $_POST['name'] ?? '';
$mobile          = $_POST['mobile'] ?? '';
$email           = $_POST['email'] ?? '';
$amount          = $_POST['amount'] ?? '';
$transactionid   = $_POST['transactionid'] ?? ('test' . date("YmdHis"));
$txnDate         = $_POST['txndate'] ?? date("YmdHis");
$addlParam1      = $_POST['addlParam1'] ?? '';
$addlParam2      = $_POST['addlParam2'] ?? '';
$udf1            = trim($_POST['udf1'] ?? '');
$udf2            = trim($_POST['udf2'] ?? '');
$udf3            = trim($_POST['udf3'] ?? '');


// === Base data ===
$data = [
    'addlParam1'       => $addlParam1,
    'addlParam2'       => $addlParam2,
    'aggregatorID'     => $aggregatorid,
    'amount'           => $amount,
    'currencyCode'     => '356',
    'customerEmailID'  => $email,
    'customerMobileNo' => $mobile,
    'customerName'     => $name,
    'merchantId'       => $merchantid,
    'merchantTxnNo'    => $transactionid,
    'payType'          => '0',
    'returnURL'        => $returnurl,
    'transactionType'  => 'SALE',
    'txnDate'          => $txnDate
];

// === Add udfFields if present ===
$hasUdf = $udf1 !== '' || $udf2 !== '' || $udf3 !== '';

if ($hasUdf) {
    $udfFields = [
        [
            'udf21' => $udf1,
            'udf22' => $udf2,
            'udf23' => $udf3
        ]
    ];
    $data['udfFields'] = $udfFields;
}

// === Sort data alphabetically (keys ascending) ===
ksort($data);

// === Build dataToHash dynamically ===
$dataToHash = '';
foreach ($data as $key => $value) {
    if ($key === 'udfFields' && is_array($value)) {
        // Append minified JSON of udfFields array
        $dataToHash .= json_encode($value, JSON_UNESCAPED_SLASHES);
    } else {
        $dataToHash .= $value;
    }
}

// === Generate HMAC SHA256 secure hash ===
$secureHash = hash_hmac('sha256', $dataToHash, $secretKey);
$data['secureHash'] = $secureHash;

// === Convert to JSON ===
$jsonPayload = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
echo "<pre>JSON Payload: $jsonPayload</pre>";
echo "<pre>Data To Hash: $dataToHash</pre>";

// === Send cURL ===
$ch = curl_init($apiEndpoint);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

// Disable SSL verify for localhost (development only)
if (in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1'])) {
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
}

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch);
    exit;
}
curl_close($ch);

// === Handle response ===
$responseData = json_decode($response, true);

if (isset($responseData['redirectURI'], $responseData['tranCtx'])) {
    $redirectURL = $responseData['redirectURI'] . '?tranCtx=' . $responseData['tranCtx'];
    header("Location: $redirectURL");
    exit;
} else {
    echo "Error: Missing redirectURI or tranCtx.<br><br>";
    echo "<pre>" . print_r($responseData, true) . "</pre>";
    echo "<pre>" . print_r($dataToHash, true) . "</pre>";
    echo "<pre>" . print_r($jsonPayload, true) . "</pre>";
}
?>
