<?php
$config = include('config.php');
date_default_timezone_set($config['timezone']);

// Generate unique merchant transaction ID
$uniqueTransactionId = "test" . date("YmdHis");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refund Initiation</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

<div class="form-container">

    <h2>Refund Initiation</h2>

    <form id="refundForm" action="submit_refund.php" method="POST">

        <!-- Environment -->
        <label class="formtext">Environment</label>
        <select name="environment" id="envSelect"
            style="width:100%; padding:10px; margin:10px 0; border-radius:4px; border:1px solid #ddd;">
            <option value="UAT">UAT</option>
            <option value="LIVE">LIVE</option>
        </select>

        <!-- Merchant ID -->
        <label class="formtext">Merchant ID</label>
        <input type="text" id="merchantid" name="merchantid" 
               value="<?php echo $config['UAT']['merchant_id']; ?>" readonly>

        <!-- Aggregator ID -->
        <label class="formtext">Aggregator ID</label>
        <input type="text" id="aggregatorid" name="aggregatorid" 
               value="<?php echo $config['UAT']['aggregator_id']; ?>" readonly>

        <!-- Amount -->
        <label class="formtext">Amount (Rs)</label>
        <input type="number" name="amount" step="0.01" placeholder="Enter Amount" required>

        <!-- Auto-generated Merchant Txn Number -->
        <input type="hidden" name="transactionid" value="<?php echo $uniqueTransactionId; ?>">

        <!-- Original Transaction -->
        <label class="formtext">Original Transaction No</label>
        <input type="text" name="originalid" placeholder="Enter Original TxnNo" required>

        <!-- Transaction type fixed -->
        <input type="hidden" name="transactionype" value="REFUND">

        <div class="submit-container">
            <button type="submit" id="submitButton">
                <span id="submitText">Initiate Refund</span>
                <div class="loader" id="loader"></div>
            </button>
        </div>

    </form>
</div>

<script>
    // Load config values from PHP into JS
    const config = <?php echo json_encode($config); ?>;

    const envSelect = document.getElementById('envSelect');
    const merchantInput = document.getElementById('merchantid');
    const aggregatorInput = document.getElementById('aggregatorid');

    // Update merchant and aggregator IDs on environment change
    envSelect.addEventListener('change', function () {
        let env = this.value;
        merchantInput.value = config[env]['merchant_id'];
        aggregatorInput.value = config[env]['aggregator_id'];
    });

    // Loader animation
    const refundForm = document.getElementById('refundForm');
    const loader = document.getElementById('loader');
    const submitButton = document.getElementById('submitButton');
    const submitText = document.getElementById('submitText');

    refundForm.addEventListener('submit', () => {
        submitText.style.display = "none";
        loader.style.display = "block";
        submitButton.disabled = true;
    });
</script>

</body>
</html>
