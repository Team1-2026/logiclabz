<?php
echo "Server Public IP: " . file_get_contents('https://api.ipify.org');