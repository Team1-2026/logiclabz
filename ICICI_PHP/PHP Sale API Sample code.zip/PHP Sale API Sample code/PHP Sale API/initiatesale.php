<?php
session_start();

// Load config
$config = include('config.php');
date_default_timezone_set($config['timezone']);

// Generate unique transaction ID
$uniqueTransactionId = "test" . date("YmdHis");
$uniqueTransactionDate = date("YmdHis");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Initiation</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="form-container">

    <h2>test Payment Form</h2>

    <form id="paymentForm" action="submit_payment.php" method="POST">

        <!-- Environment -->
        <label class="formtext" for="environment">Environment</label>
        <select id="environment" name="environment" required
                style="width:100%; padding:10px; margin:10px 0; border-radius:4px; border:1px solid #ddd;">
            <option value="UAT">UAT</option>
            <option value="LIVE">LIVE</option>
        </select>

        <!-- Merchant ID -->
        <label class="formtext" for="merchantid">Merchant ID</label>
        <input type="text" id="merchantid" name="merchantid"
               value="<?php echo $config['UAT']['merchant_id']; ?>" readonly>

        <!-- Aggregator ID -->
        <label class="formtext" for="aggregatorid">Aggregator ID</label>
        <input type="text" id="aggregatorid" name="aggregatorid"
               value="<?php echo $config['UAT']['aggregator_id']; ?>" readonly>

        <!-- User Details -->
        <label class="formtext" for="name">Name</label>
        <input type="text" id="name" name="name" required placeholder="Enter Name">

        <label class="formtext" for="mobile">Mobile Number</label>
        <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" required placeholder="Enter 10-digit mobile number">

        <label class="formtext" for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="Enter Email">

        <label class="formtext" for="amount">Payment Amount (Rs)</label>
        <input type="number" id="amount" name="amount" required step="0.01" placeholder="Enter amount">

        <!-- Hidden Fields -->
        <input type="hidden" id="transactiontype" name="transactiontype" value="SALE">
        <input type="hidden" id="transactionid" name="transactionid" value="<?php echo $uniqueTransactionId; ?>">
        <input type="hidden" id="txndate" name="txndate" value="<?php echo $uniqueTransactionDate; ?>">

        <div class="submit-container">
            <button type="submit" id="submitButton">
                <span id="submitText">Submit Payment</span>
                <div class="loader" id="loader"></div>
            </button>
        </div>

    </form>
</div>

<script>
    const config = <?php echo json_encode($config); ?>;

    const envSelect = document.getElementById('environment');
    const merchantInput = document.getElementById('merchantid');
    const aggregatorInput = document.getElementById('aggregatorid');

    // Auto update merchant and aggregator IDs on environment change
    envSelect.addEventListener('change', function () {
        const env = this.value;
        merchantInput.value = config[env]['merchant_id'];
        aggregatorInput.value = config[env]['aggregator_id'];
    });

    // Loader animation on form submit
    const paymentForm = document.getElementById('paymentForm');
    const loader = document.getElementById('loader');
    const submitButton = document.getElementById('submitButton');
    const submitText = document.getElementById('submitText');

    paymentForm.addEventListener('submit', () => {
        submitText.style.display = "none";
        loader.style.display = "block";
        submitButton.disabled = true;
    });

    // Reload page if user comes back using browser back button
    window.addEventListener("pageshow", function (event) {
        if (event.persisted) {
            window.location.reload();
        }
    });
</script>

</body>
</html>
