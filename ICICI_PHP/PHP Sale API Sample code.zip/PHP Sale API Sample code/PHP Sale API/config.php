<?php
/**
 * Configuration file for Payment Gateway
 * Editable values: endpoints and return URL.
 */
return [
    'UAT' => [
        'merchant_id' => '100000000007164',
        'aggregator_id' => 'A100000000007164',
        'key' => 'db06cca0-838b-4e01-8b20-6ac446ffb6bd',
        'api' => [
            'initiate_sale' => 'https://pgpayuat.icicibank.com/tsp/pg/api/v2/initiateSale',
            'status'        => 'https://pgpayuat.icicibank.com/tsp/pg/api/command',
            'refund'        => 'https://pgpayuat.icicibank.com/tsp/pg/api/command'
        ],
        'return_url' => 'https://payment.testpg.store/payment_response.php'
    ],

    'LIVE' => [
        'merchant_id' => 'YourMerchantId',
        'aggregator_id' => 'YourAgregatorId',
        'key' => 'YourSecretKey',
        'api' => [
            'initiate_sale' => 'https://pgpay.icicibank.com/pg/api/v2/initiateSale',
            'status'        => 'https://pgpay.icicibank.com/pg/api/command',
            'refund'        => 'https://pgpay.icicibank.com/pg/api/command'
        ],
        'return_url' => 'https://payment.testpg.store/payment_response.php'
    ],

    'timezone' => 'Asia/Kolkata'
];
