<?php
// Start session to access session data
session_start();

// Set the default timezone to IST (Indian Standard Time)
date_default_timezone_set('Asia/Kolkata');

// Generate the unique transaction ID with the format test-ddmmyyyyhhmmss
$uniqueTransactionId = "test" . date("YmdHis");

// Store the current date and time in the required format (ddmmyyyyhhmmss)
$uniqueTransactionDate = date("YmdHis");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Initiation</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="form-container">
       
        <h2> Payment Form</h2>
        <form id="paymentForm" action="submit_payment.php" method="POST">

         <label class="formtext" for="merchantid">Merchant ID</label>
            <input type="text" id="merchantid" name="merchantid" value = "T_03343" required placeholder="Enter Merchant ID">

            <label class="formtext" for="aggregatorid">Aggregator ID</label>
            <input type="text" id="aggregatorid" name="aggregatorid" value = "J_03345" required  placeholder="Enter Aggregator ID">

            <label class="formtext" for="key">Merchant Key</label>
            <input type="text" id="key" name="key" required value = "abc"  placeholder="Enter Key">

            <label class="formtext" for="name">Name</label>
            <input type="text" id="name" name="name" required placeholder="Enter Name" >
            
            <label class="formtext" for="mobile">Mobile Number</label>
            <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" required placeholder="Enter 10-digit mobile number">
             
            <label class="formtext" for="email">Email Address</label>
            <input type="email" id="email" name="email"  placeholder="Enter Email" >

            <label class="formtext" for="amount">Payment Amount (Rs)</label>
            <input type="number" id="amount" name="amount" required step="0.01"  placeholder="Enter amount" >

              <!-- Additional Parameters -->
            <label class="formtext" for="addlParam1">Additional Param 1</label>
            <input type="text" id="addlParam1" name="addlParam1" placeholder="Enter Addl Param 1">

            <label class="formtext" for="addlParam2">Additional Param 2</label>
            <input type="text" id="addlParam2" name="addlParam2" placeholder="Enter Addl Param 2">


                        <!-- UDF Fields -->
            <!-- <label class="formtext" for="udf1">UDF 1</label>
            <input type="text" id="udf1" name="udf1" placeholder="Optional custom field 1">

            <label class="formtext" for="udf2">UDF 2</label>
            <input type="text" id="udf2" name="udf2" placeholder="Optional custom field 2">

            <label class="formtext" for="udf3">UDF 3</label>
            <input type="text" id="udf3" name="udf3" placeholder="Optional custom field 3"> -->

            <!-- Hidden Fields to Submit Specific Parameters -->
            <input type="hidden" id="transactionype" name="transactiontype" value="SALE">
            <input type="hidden" id="transactionid" name="transactionid" value="<?php echo $uniqueTransactionId; ?>">
            <input type="hidden" id="txndate" name="txndate" value="<?php echo $uniqueTransactionDate; ?>">


            <div class="submit-container">
                <button type="submit" id="submitButton">
                    <span id="submitText">Submit Payment</span>
                    <div class="loader" id="loader"></div>
                </button>
            </div>
        </form>
    </div>

    <script>
        // Grab the form, loader, and submit button elements
        const paymentForm = document.getElementById('paymentForm');
        const loader = document.getElementById('loader');
        const submitButton = document.getElementById('submitButton');
        const submitText = document.getElementById('submitText');

        // Add a submit event listener to the form
        paymentForm.addEventListener('submit', function (e) {
            // Show the loader inside the button and hide the submit button text when the form is submitted
            loader.style.display = 'inline-block';
            submitText.style.display = 'none';  // Hide the button text
            submitButton.disabled = true;  // Disable the button to prevent multiple submissions

        });
    </script>

</body>
</html>
