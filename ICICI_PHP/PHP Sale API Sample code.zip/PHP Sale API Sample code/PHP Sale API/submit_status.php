<?php
session_start();

// Load config
$config = include('config.php');

// Get environment
$env = $_POST['environment'] ?? 'UAT';

// Read values from config
$merchantid   = $config[$env]['merchant_id'];
$aggregatorid = $config[$env]['aggregator_id'];
$secretKey    = $config[$env]['key'];
$statusUrl    = $config[$env]['api']['status'];

// Read POST values
$transactiontype = 'STATUS';
$transactionid   = $_POST['transactionid'] ?? '';
$originalid      = $_POST['originalid'] ?? '';

// Prepare data for HMAC - (NO AMOUNT)
$data = [
    'merchantTxnNo'   => $transactionid,
    'originalTxnNo'   => $originalid,
    'transactionType' => $transactiontype,
    'aggregatorID'    => $aggregatorid,
    'merchantId'      => $merchantid
];

ksort($data);

// Build string for HMAC
$dataToHash = '';
foreach ($data as $value) {
    $dataToHash .= $value;
}

// Debug – sorted data
echo "<script>console.log('Sorted Data: " . json_encode($data) . "')</script>";

// Generate secure hash
$secureHash = hash_hmac('sha256', $dataToHash, $secretKey);

// Final request payload
$requestData = [
    'merchantId'      => $merchantid,
    'aggregatorID'    => $aggregatorid,
    'merchantTxnNo'   => $transactionid,
    'originalTxnNo'   => $originalid,
    'transactionType' => $transactiontype,
    'secureHash'      => $secureHash
];

$jsonPayload = json_encode($requestData);

// Debug – request data
echo "<script>console.log('Request Data: " . json_encode($requestData) . "')</script>";

// CURL CALL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $statusUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);

// Error check
if (curl_errno($ch)) {
    echo "CURL Error: " . curl_error($ch);
    exit;
}

curl_close($ch);

// Decode response
$responseData = json_decode($response, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo "Invalid JSON response.";
    exit;
}

// Display Response Table
echo "<h3>API Response</h3>";
echo "<table border='1' cellpadding='5' cellspacing='0'>";
echo "<tr><th>Parameter</th><th>Value</th></tr>";

foreach ($responseData as $key => $value) {
    echo "<tr><td>" . htmlspecialchars($key) . "</td><td>" . htmlspecialchars($value) . "</td></tr>";
}

echo "</table>";
?>
